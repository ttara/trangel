#This program calculates the distance between
#two points
import numpy as np
import matplotlib.pyplot as plt


A = np.array([-2,-2]) 
B = np.array([1,3]) 
C = np.array([4,-1]) 

print (np.linalg.norm(A-B))

